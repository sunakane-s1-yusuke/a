'use strict';

const datalockerLogStore = require('./lib/datalockerLogStore');

module.exports.DatalockerLogStore = datalockerLogStore;
module.exports.contracts = [datalockerLogStore];
